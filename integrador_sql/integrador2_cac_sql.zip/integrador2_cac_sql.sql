-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.28 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla integrador_cac.oradores: ~0 rows (aproximadamente)
INSERT INTO `oradores` (`id_orador`, `nombre`, `apellido`, `mail`, `tema`, `fecha_alta`) VALUES
	(1, 'Gustavo', 'Lopez', 'guslo@hotmail.com', 'React', '2023-11-05'),
	(2, 'Beatriz', 'Murillo', 'muri@gmail.com', 'Javascript', '2023-11-05'),
	(3, 'Ignacio', 'Perez', 'Pere02@gmail.com', 'Java', '2023-10-05'),
	(4, 'Cecilia', 'Sanchez', 'Cecisan@hotmail.com', 'MySQL', '2023-10-01'),
	(5, 'Pedro', 'Igna', 'pepe@hotmail.com', 'React', '2023-11-04'),
	(6, 'Augusto', 'Parmeggiani', 'Augu0204@gmail.com', 'Javascript', '2023-10-22'),
	(7, 'Patricia', 'Macarin', 'patrimasca@gmail.com', 'React', '2023-11-05'),
	(8, 'Alejandra', 'Ciranni', 'cira1514@gmail.com', 'MySQL', '2023-10-14'),
	(9, 'Noelia', 'Aleman', 'alemanita@gmail.com', 'Java', '2023-11-05'),
	(10, 'Juan', 'Gagliardi', 'juangaga@hotmail.com', 'Java', '2023-11-01');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
